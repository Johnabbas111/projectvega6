const express = require("express");
const upload = require("../controllers/profileImageController");
const router = express.Router();
// const upload = require("../controllers/profileImageController/upload");

// POST route to upload profile image
router.post("/upload", upload.single("profileImage"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No file uploaded.");
  }
  res.status(200).json({
    filename: req.file.filename,
    path: `/uploads/${req.file.filename}`,
  });
});

module.exports = router;
