const express = require("express");
const router = express.Router();
const {
  getAllBlog,
  getBlogDetails,
  createBlog,
  updateBlog,
  deleteBlog,
} = require("../controllers/blogController");
const { protect } = require("../middlewares/authMiddleare");

// Get all blog Route
router.route("/blog/getAll").get(protect, getAllBlog);

// Get blog details Route
router.route("/blog/get/:id").get(protect, getBlogDetails);

// Create blog Route
router.route("/blog/create").post(protect, createBlog);

// Update blog Route
router.route("/blog/update/:id").put(protect, updateBlog);

// Delete blog Route
router.route("/blog/delete/:id").delete(protect, deleteBlog);

module.exports = router;
