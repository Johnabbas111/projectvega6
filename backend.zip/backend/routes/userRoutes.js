const express = require("express");
const router = express.Router();
const {
  signUpUser,
  getUser,
  loginUser,
} = require("../controllers/userController");
const { protect } = require("../middlewares/authMiddleare");

// Register user Route

router.route("/user/signup").post(signUpUser);

// Get user profile Route
router.route("/user/get").get(protect, getUser);

// Login user Route
router.route("/user/login").post(loginUser);

module.exports = router;
