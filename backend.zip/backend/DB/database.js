const mongoose = require("mongoose");

const connect = async () => {
  try {
    const database = await mongoose.connect(process.env.URI);

    console.log(
      `Database connected successfully with ${database.connection.host}`
    );
  } catch (error) {
    console.log(error.message);
  }
};

module.exports = connect;
