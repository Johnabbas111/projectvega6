const User = require("../models/userSchema");
const jwt = require("jsonwebtoken");

const protect = async (req, res, next) => {
  let token;
  // Check if the request contains a valid JWT token
  if (!req.headers.authorization) {
    return res
      .status(401)
      .json({ success: false, message: "Unauthorized: Missing token" });
  }
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      token = req.headers.authorization.split(" ")[1];
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Add user from payload
      req.user = await User.findById(decoded.id);
      // console.log(req.user);
      next();
    } catch (error) {
      console.error(error);
      res.status(401).json({ message: "Not authorized, token failed" });
    }
  }

  if (!token) {
    res.status(401).json({ message: "Not authorized, No token" });
  }
};

module.exports = {
  protect,
};
