const express = require("express");
const dotenv = require("dotenv");
const connect = require("./DB/database");
const path = require("path");
const profileImageRoutes = require("./routes/profileImageRoutes");
const userRoutes = require("./routes/userRoutes");
const blogRoutes = require("./routes/blogRoutes");

const app = express();
dotenv.config();

app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads"))); // Serve static files from the uploads folder

const PORT = process.env.PORT || 3000;

connect();

// Routes
app.use("/api/v1", profileImageRoutes);
app.use("/api/v1", userRoutes);
app.use("/api/v1", blogRoutes);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
