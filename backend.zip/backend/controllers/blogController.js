const expressAsyncHandler = require("express-async-handler");
const Blog = require("../models/blogSchema");

// Get All Blog

const getAllBlog = expressAsyncHandler(async (req, res, next) => {
  try {
    const blogs = await Blog.find({});
    if (blogs.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "No blog available to show!" });
    }
    res.status(200).json({ success: true, blogs });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: err.message });
  }
});

// Get Blog Details

const getBlogDetails = expressAsyncHandler(async (req, res, next) => {
  try {
    let { id } = req.params;

    let blog = await Blog.findById({ _id: id });
    if (!blog) {
      return res.status(404).json({
        success: false,
        message: "Blog not found!",
      });
    }

    res.status(200).json({ success: true, blog });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: err.message });
  }
});

// Create Blog

const createBlog = expressAsyncHandler(async (req, res, next) => {
  let { blogTitle, blogDescription, blogImage } = req.body;
  try {
    if (!blogTitle || !blogDescription || !blogImage) {
      return res
        .status(400)
        .json({ success: false, message: "All fieldes are required." });
    }

    let blog = new Blog({
      blogTitle,
      blogDescription,
      blogImage,
    });

    blog = await blog.save();
    res
      .status(200)
      .json({ success: true, message: "Blog created successfully", blog });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: err.message });
  }
});

// Update Blog

const updateBlog = expressAsyncHandler(async (req, res, next) => {
  try {
    let { id } = req.params;

    let blog = await Blog.findById({ _id: id });
    if (!blog) {
      return res.status(404).json({
        success: false,
        message: "Blog not found!",
      });
    }

    blog = await Blog.findByIdAndUpdate({ _id: id }, req.body, {
      new: true,
    });
    res
      .status(200)
      .json({ success: true, message: "Blog updated successfully", blog });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: err.message });
  }
});

// Delete Blog

const deleteBlog = expressAsyncHandler(async (req, res, next) => {
  try {
    let { id } = req.params;

    let blog = await Blog.findByIdAndDelete({ _id: id });
    if (!blog) {
      return res.status(404).json({
        success: false,
        message: "Blog not found!",
      });
    }

    res
      .status(200)
      .json({ success: true, message: "Blog deleted successfully", blog });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: err.message });
  }
});

module.exports = {
  getAllBlog,
  getBlogDetails,
  createBlog,
  updateBlog,
  deleteBlog,
};
