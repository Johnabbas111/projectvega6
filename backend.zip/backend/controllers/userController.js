var bcrypt = require("bcryptjs");
const User = require("../models/userSchema");
const { generateToken } = require("../middlewares/tokenGenerate");
const expressAsyncHandler = require("express-async-handler");

const signUpUser = async (req, res, next) => {
  let { email, password, profileImage } = req.body;

  try {
    if (!email || !password || !profileImage) {
      return res
        .status(400)
        .json({ success: false, message: "All fieldes are required." });
    }

    let user = await User.findOne({ email });

    if (user) {
      return res.status(400).json({
        success: false,
        message: "User is alredy exist!",
      });
    }

    const hash = await bcrypt.hash(password, 10);

    password = hash;

    user = new User({
      email,
      password,
      profileImage,
    });

    user = await user.save();

    const token = generateToken(user._id);

    res.status(200).json({
      success: true,
      user,
      token,
      message: "User register successfully",
    });

    console.log(hash, "hash Pass");
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const loginUser = async (req, res, next) => {
  let { email, password } = req.body;

  try {
    if (!email || !password) {
      return res
        .status(400)
        .json({ success: false, message: "All fieldes are required." });
    }

    let user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "User is does not exist!",
      });
    }

    let comparePassword;

    if (user) {
      comparePassword = await bcrypt.compare(password, user.password);
    }

    if (!comparePassword) {
      return res.status(400).json({
        success: false,
        message: "Incorrect password",
      });
    }

    if (comparePassword) {
      const token = generateToken(user._id);
      res.status(200).json({
        success: true,
        user,
        token,
        message: "User login successfully",
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getUser = expressAsyncHandler(async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }
    res.status(200).json({ success: true, user });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: "Server Error" });
  }
});

module.exports = { signUpUser, getUser, loginUser };
